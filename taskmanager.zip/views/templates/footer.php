</div>
<footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600"></footer>
<script defer="defer" src="<?php echo BASE_DIR;?>/js/main.js"></script>
</body>
</html>
